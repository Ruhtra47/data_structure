#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

long long hash(char *str, int base, int table_size)
{
    long long val = 0;
    for (int i = strlen(str) - 1; i >= 0; i--)
    {
        val += str[i] * pow(base, strlen(str) - i - 1);
        val %= table_size;
    }
    return val;
}

int main()
{
    int base, n, table_size;
    scanf("%d %d %d", &base, &n, &table_size);

    for (int i = 0; i < n; i++)
    {
        char str[30];
        scanf("%s", str);

        printf("%llu\n", hash(str, base, table_size));
    }
}