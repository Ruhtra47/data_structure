#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

long long hash(char *str, int base)
{
    long long val = 0;
    for (int i = strlen(str) - 1; i >= 0; i--)
    {
        val += str[i] * pow(base, strlen(str) - i - 1);
    }
    return val;
}

int main()
{
    int base, n;
    scanf("%d %d", &base, &n);

    for (int i = 0; i < n; i++)
    {
        char str[30];
        scanf("%s", str);

        printf("%llu\n", hash(str, base));
    }
}