#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "node.h"

int main() {
    int n;
    scanf("%d", &n);

    Node *cabeca = NULL;
    data_type value;
    for (int i = 0; i < n; i++) {
        scanf("%d", &value);
        cabeca = node_construct(value, cabeca);
    }

    Node* to_free = NULL;
    while (cabeca != NULL) {
        printf("%d\n", node_value(cabeca));
        to_free = cabeca;
        cabeca = node_next(cabeca);
        node_destroy(to_free);
    }
}