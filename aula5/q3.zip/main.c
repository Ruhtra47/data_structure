#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "frame.h"
#include "atendimento.h"
#include "queue.h"

int main()
{
    char tipo[10];
    scanf("%s", tipo);

    if (!strcmp(tipo, "SENHAS"))
    {
        int n;
        scanf("%d", &n);

        Queue *senhas = queue_constructor(10);

        for (int i = 0; i < n; i++)
        {
            char cmd[10];
            scanf("%s", cmd);

            if (!strcmp(cmd, "ADICIONAR"))
            {
                char nome[50], cpf[12];
                scanf("%s %s", nome, cpf);

                if (queue_is_full(senhas))
                {
                    printf("FILA CHEIA\n");
                    continue;
                }

                Atendimento *at = atendimento_constructor(nome, cpf);

                queue_add(senhas, at);
            }
            else if (!strcmp(cmd, "CHAMAR"))
            {
                if (queue_is_empty(senhas))
                {
                    printf("FILA VAZIA\n");
                    continue;
                }

                Atendimento *at = (Atendimento *)queue_remove(senhas);

                printf("%s\n", atendimento_get_nome(at));

                atendimento_destroy(at);
            }
        }

        while (!queue_is_empty(senhas))
        {
            atendimento_destroy((Atendimento *)queue_remove(senhas));
        }
        queue_destroy(senhas);
    }
    else if (!strcmp(tipo, "STREAMING"))
    {
        int n;
        scanf("%d", &n);

        Queue *fila = queue_constructor(20);

        for (int i = 0; i < n; i++)
        {
            char cmd[10];
            scanf("%s", cmd);

            if (!strcmp(cmd, "ADICIONAR"))
            {
                if (queue_is_full(fila))
                {
                    printf("FILA CHEIA\n");
                    scanf("%*s %*d %*f");
                    continue;
                }

                char video_id[50];
                int frame_id;
                float timestamp;

                scanf("%s %d %f", video_id, &frame_id, &timestamp);

                Frame *f = frame_constructor(video_id, frame_id, timestamp);

                queue_add(fila, f);
            }
            else if (!strcmp(cmd, "PLAY"))
            {
                if (queue_size(fila) < 5)
                {
                    printf("AGUARDE\n");
                    continue;
                }

                for (int j = 0; j < 5; j++)
                {
                    Frame *f = (Frame *)queue_remove(fila);

                    printf("ID: %d, Timestamp: %.2f\n", frame_get_frame_id(f), frame_get_timestamp(f));
                    frame_destroy(f);
                }
            }
        }

        while (!queue_is_empty(fila))
        {
            frame_destroy((Frame *)queue_remove(fila));
        }
        queue_destroy(fila);
    }
}