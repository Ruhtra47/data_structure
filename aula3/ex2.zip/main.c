

#include <stdio.h>
#include <stdlib.h>
#include "product.h"

Product *create_product()
{
    char name[128];
    float price;
    int qtd;
    int n_sales;

    scanf("%[^\n]\n", name);
    scanf("%f", &price);
    scanf("%d", &qtd);
    scanf("%d\n", &n_sales);

    Product *p = product_constructor(name, price, qtd);
    product_sell(p, n_sales);

    return p;
}

void perform_operation(Product *product)
{
    char name[128];
    float price, discount;
    int qtd;
    char operation;

    scanf("\n%c", &operation);

    if (operation == 'P')
        product_print(product);
    else if (operation == 'S')
    {
        scanf("\n%d", &qtd);
        product_sell(product, qtd);
    }
    else if (operation == 'B')
    {
        scanf("\n%d", &qtd);
        product_buy(product, qtd);
    }
    else if (operation == 'D')
    {
        scanf("\n%f", &discount);
        product_set_discount(product, discount);
    }
    else if (operation == 'Q')
    {
        scanf("\n%f", &price);
        product_set_price(product, price);
    }
    else if (operation == 'N')
    {
        scanf("\n%[^\n]\n", name);
        product_set_name(product, name);
    }
    else
        printf("Operacao invalida.\n");
}

int main()
{
    // Product *product = create_product();

    // int n_operations;
    // scanf("%d", &n_operations);

    // for (int i = 0; i < n_operations; ++i)
    //     perform_operation(product);

    // product_destructor(product);

    int n_products;
    scanf("%d\n", &n_products);

    Product *products[n_products];
    for (int i = 0; i < n_products; i++) {
        products[i] = create_product();
    }

    char c;
    scanf("%c", &c);

    if (c == 'N')
        qsort(products, n_products, sizeof(Product*), product_compare_name);
    else if (c == 'P')
        qsort(products, n_products, sizeof(Product*), product_compare_price);
    else if (c == 'S')
        qsort(products, n_products, sizeof(Product*), product_compare_sales);

    for (int i = 0; i < n_products; i++) {
        product_print(products[i]);
    }

    return 0;
}
