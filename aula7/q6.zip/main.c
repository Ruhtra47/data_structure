#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "node.h"
#include "stack.h"
#include "queue.h"
#include "deque.h"

int main()
{
    int n;
    scanf("%d", &n);

    // Stack *s = stack_construct();
    // Queue *q = queue_construct();
    Deque *dq = deque_construct();

    char cmd[10];
    for (int i = 0; i < n; i++)
    {
        scanf("%s", cmd);

        if (!strcmp(cmd, "PUSH_FRONT"))
        {
            int item;
            scanf("%d", &item);

            deque_push_front(dq, item);
        }
        else if (!strcmp(cmd, "PUSH_BACK"))
        {
            int item;
            scanf("%d", &item);

            deque_push_back(dq, item);
        }
        else if (!strcmp(cmd, "POP_FRONT"))
        {
            int removed = deque_pop_front(dq);

            printf("%d\n", removed);
        }
        else if (!strcmp(cmd, "POP_BACK"))
        {
            int removed = deque_pop_back(dq);

            printf("%d\n", removed);
        }
    }

    deque_destroy(dq);
}