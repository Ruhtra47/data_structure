#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "node.h"
#include "stack.h"
#include "queue.h"

int main()
{
    int n;
    scanf("%d", &n);

    // Stack *s = stack_construct();
    Queue *q = queue_construct();

    char cmd[10];
    for (int i = 0; i < n; i++)
    {
        scanf("%s", cmd);

        if (!strcmp(cmd, "ENQUEUE"))
        {
            char *to_insert = (char *)malloc(100 * sizeof(char));

            scanf("%s", to_insert);

            queue_enqueue(q, to_insert);
        }
        else if (!strcmp(cmd, "DEQUEUE"))
        {
            char *removed = (char *)queue_dequeue(q);

            printf("%s\n", removed);
            free(removed);
        }
    }

    queue_destroy(q);
}