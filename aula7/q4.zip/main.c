#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "node.h"
#include "stack.h"

int main()
{
    int n;
    scanf("%d", &n);

    Stack *s = stack_construct();

    char cmd[10];
    for (int i = 0; i < n; i++)
    {
        scanf("%s", cmd);

        if (!strcmp(cmd, "PUSH"))
        {
            char *to_insert = (char *)malloc(100 * sizeof(char));

            scanf("%s", to_insert);

            stack_push(s, to_insert);
        }
        else if (!strcmp(cmd, "POP"))
        {
            char *removed = (char *)stack_pop(s);

            printf("%s\n", removed);
            free(removed);
        }
    }

    stack_destroy(s);
}